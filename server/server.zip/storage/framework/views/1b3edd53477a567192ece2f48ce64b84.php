<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reset your password</title>
</head>

<body>
    <p>Mã xác nhận của bạn là: <?php echo e($token); ?></p>
</body>

</html>
<?php /**PATH E:\Workspace\project\3000\server\resources\views/emails/passwordReset.blade.php ENDPATH**/ ?>