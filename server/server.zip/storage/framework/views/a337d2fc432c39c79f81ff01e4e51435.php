<a href="/api/docs">API</a>
<?php /**PATH E:\Workspace\project\3000\server\resources\views/welcome.blade.php ENDPATH**/ ?>